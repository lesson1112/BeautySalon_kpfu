﻿using BeautySalon;

class Program
{
    static void Main(string[] args)
    {
        SalonMenu menu = new SalonMenu();
        menu.Start();
    }
}
//